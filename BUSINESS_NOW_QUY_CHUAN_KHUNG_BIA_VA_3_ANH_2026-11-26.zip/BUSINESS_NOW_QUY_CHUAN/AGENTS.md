# Quy trình BUSINESS NOW

Đọc README.md, QUY_UOC_CHUAN.md và GHI_CHU_CHINH_SUA.md trước khi làm ảnh. Đây là quy trình ba ảnh cho từng kịch bản, không phải lịch chạy tự động và không tự mở rộng sang viết kịch bản hoặc sản xuất video.

- Lưu thành phẩm mặc định dưới D:/Ảnh GPT, mỗi số bài một thư mục, đúng ba PNG 1080×1920.
- 01 quá khứ sạch; 02 giai đoạn thành công sạch; 03 ảnh khác với khung cam đã chốt và hook.
- Rõ mặt, đúng người, không dùng ảnh quá mờ; mặt phải tránh dải chữ. Thử chữ thật rồi giao bản sạch cho 01/02.
- Không lặp cùng ảnh gốc, kể cả ảnh đổi màu/cắt/đổi nền và các thành phần ảnh ghép. Đối chiếu bộ cũ nếu có.
- Khi ảnh 02 dùng doanh nghiệp/sản phẩm, mặc định ghép dọc trên người, dưới cơ sở/sản phẩm, trừ yêu cầu riêng rõ ràng.
- Dùng nguyên mẫu khung, logo và cách xuất chữ tiếng Việt trong assets/ và src/. Không tự thiết kế lại.
- Không ghi ngày chụp, thời thơ ấu hoặc sự kiện mà nguồn chưa xác minh.
- Nguồn, nháp và báo cáo ở workspace, không trộn vào ba ảnh bàn giao. Chỉ tạo ZIP khi được yêu cầu.
- Tôn trọng yêu cầu điều chỉnh rõ ràng mới nhất của chủ dự án.
