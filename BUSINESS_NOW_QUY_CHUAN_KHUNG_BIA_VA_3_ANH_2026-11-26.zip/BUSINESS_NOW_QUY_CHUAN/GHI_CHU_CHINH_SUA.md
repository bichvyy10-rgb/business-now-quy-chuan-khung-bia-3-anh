# Những chỉnh sửa và ghi chú đã được nạp

Tài liệu này tóm lại các yêu cầu trực tiếp trong lịch sử làm việc. Không phải toàn bộ hội thoại và không chứa ảnh/kịch bản đã sản xuất.

## Yêu cầu đã trở thành quy tắc chung

| Ghi chú của chủ dự án | Cách áp dụng cho các bài sau |
| --- | --- |
| Muốn khung giống các bìa video mẫu, nhưng cam nhạt | Giữ mẫu khung cam đã chốt, không tự thiết kế lại phong cách |
| Muốn màu mờ giống mẫu | Khung cam trong mờ; ảnh nhân vật vẫn phải rõ nét |
| Logo riêng BUSINESS NOW, bỏ nền, theo hàng ngang và nhỏ vừa đủ | Dùng logo của chủ dự án, không dùng HBR Business School/Vietnam Brand Insider từ video mẫu; không phóng logo quá lớn |
| Khi kịch bản nói về ai thì đưa mặt người đó vào | Bìa phải đúng nhân vật; tự chèn khung và hook khi làm bộ ảnh |
| Mỗi lần yêu cầu chỉ cần ba ảnh: quá khứ, hiện tại và bìa | Bàn giao ba thành phẩm, không trả đống ảnh tìm kiếm để chủ dự án tự làm |
| Muốn ảnh dọc để làm Reels | Xuất 9:16, 1080×1920 |
| Có ảnh không phù hợp để chèn chữ | Chọn bố cục trước; thử chữ thật, không chỉ tìm chân dung cận mặt |
| Chữ bị mất dấu, font xấu/lỗi so với mẫu | Giữ đủ dấu tiếng Việt và kiểu chữ cao, hẹp, đậm đã duyệt; dùng cách vẽ glyph tránh cắt dấu |
| Ảnh áo trắng làm phía dưới trống | Đổi ảnh/bố cục để phần thân và bối cảnh phủ dưới; tránh mảng trắng lớn |
| Chèn chữ đè lên mặt tùm lum | Đưa mặt lên phần trên, chừa dải chữ ở khoảng 35–55% chiều cao; kiểm tra cả lô |
| Không dùng ảnh quá mờ; kiểm tra lại tất cả ảnh liên quan | Soi bản xuất thực tế, tìm nguồn khác; không chỉ phóng lớn hoặc làm nét giả |
| Không lưu Downloads nữa; tạo thư mục Ảnh GPT trên D | Lưu mặc định ở D, mỗi số bài một thư mục, chỉ ba thành phẩm |
| Trong D có quá nhiều ảnh, xóa cái không cần | Giữ khu vực bàn giao gọn, đưa nguồn/nháp/bản sao lưu về workspace; không xóa bừa dữ liệu khác |
| Ảnh 02 là doanh nghiệp/sản phẩm thì cắt đôi thêm doanh nhân | Mặc định trên người, dưới doanh nghiệp/sản phẩm/nhà máy; áp dụng nhất quán khi dùng dạng này |
| Ảnh không được trùng nhau | Rà ảnh gốc lẫn ảnh cắt/đổi màu/đổi nền và từng phần trong ảnh ghép; thay nguồn ảnh khi trùng |

## Ví dụ riêng trong lịch sử — dùng để hiểu yêu cầu

- **Jan Koum:** chủ dự án yêu cầu đúng người, thêm tư liệu quá khứ, chọn ảnh thuận lợi chèn chữ và cắt thành 9:16; ba ảnh phải khác nhau.
- **Oprah, kịch bản 01:** đã yêu cầu sửa font/dấu, đổi ảnh áo trắng và chốt bìa váy tím với hook `TUỔI THƠ NGHÈO KHÓ, / OPRAH LẠI MẤT / GHẾ DẪN TIN.` Đây là nội dung riêng của bài 01, không dùng làm hook mặc định cho bài mới.
- **Crocs, kịch bản 31:** muốn thương hiệu dễ nhận ra; ảnh 02 phải khác bìa, có thể thay bằng công ty/nhà máy hiện nay khi ảnh sản phẩm đã trùng bìa.
- **Kịch bản 49:** câu hỏi “ảnh 02 có phải ổng không” nhắc phải xác minh người trong ảnh, không tin nhãn kết quả tìm kiếm.
- **Kịch bản 143 và 225:** được dùng làm ví dụ ảnh mờ; yêu cầu là kiểm tra và thay các ảnh mờ trong cả bộ liên quan.
- **VNG:** ảnh 02 cần chia đôi, có cơ sở VNG hiện nay thể hiện quy mô rõ ràng.
- **TTC, kịch bản 161:** nửa trên ông doanh nhân TTC, nửa dưới cơ sở tập đoàn lớn; Highlands được yêu cầu làm tương tự.
- **Kịch bản 172:** bìa từng bị mất tên thương hiệu; ảnh 02 có yêu cầu riêng ghép sản phẩm với không gian quán đông khách. Đây là ngoại lệ theo yêu cầu của bài, không thay cho mặc định trên người/dưới doanh nghiệp ở mọi bài.
- **Kịch bản 205:** ảnh 01 không có người bị phản hồi; bài về một nhân vật cần có nhân vật rõ ràng trong ảnh 01.
- **Bộ 231–300:** đã yêu cầu rà trùng cả phần ảnh doanh nghiệp và chân dung; thay cả các bản thực chất là cùng ảnh nhưng đổi màu/nền hoặc xuất hiện lại trong bảng trưng bày.
- **Oprah và Tyler Perry trong bộ 321–330:** đã đối chiếu bộ 01 và 19 cũ khi chọn ảnh bìa mới để tránh lặp ảnh đã giao.

## Phân biệt yêu cầu với lựa chọn triển khai

- Chọn font Anton, tọa độ thử chữ, dùng đường nét glyph, tính mã ảnh và đối chiếu đặc trưng là cách triển khai để đáp ứng mẫu đã duyệt; không khẳng định video tham khảo gốc dùng đúng font này.
- Việc trước đây có bài dùng tượng, phù điêu hoặc tòa nhà khi tư liệu rất hiếm là lựa chọn đã báo rõ trong lần bàn giao đó. Không xem đây là yêu cầu chung của chủ dự án và không tự thay một người bằng tượng/tòa nhà cho các bài mới.
- Các bài viết về thời thơ ấu có thể phải dùng một ảnh tư liệu rõ hơn ở giai đoạn sau; phải phân biệt ảnh minh họa quá khứ với ảnh chụp đúng tuổi/sự kiện. Không khẳng định ngày chụp chưa xác minh.
- Yêu cầu riêng cho một bài được ưu tiên ở bài đó. Không áp dụng tên thương hiệu, hook, trang phục, quán hay nhà máy của bài cũ sang bài mới một cách máy móc.

## Phạm vi bản đóng gói này

Theo yêu cầu điều chỉnh ngày 26/11/2026: chỉ đóng gói dữ liệu làm khung bìa và các quy tắc/ghi chú đã sửa cho quy trình ba ảnh. Bỏ ảnh nhân vật, ảnh tìm kiếm và thành phẩm cũ. Giữ đúng khung, logo, font và mã tối thiểu để tái tạo mẫu.
