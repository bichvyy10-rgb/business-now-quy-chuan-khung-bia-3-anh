# Quy ước ảnh BUSINESS NOW

## 1. Một kịch bản, đúng ba ảnh

Xuất PNG dọc 9:16, **1080×1920 px**:

| Tệp | Nội dung | Chữ khi bàn giao |
| --- | --- | --- |
| `01-qua-khu-1080x1920.png` | Nhân vật trong quá khứ, ưu tiên thời trẻ/giai đoạn khó khăn | Ảnh sạch để chủ dự án chèn nội dung |
| `02-hien-tai-1080x1920.png` | Nhân vật ở giai đoạn thành công; có thể ghép với doanh nghiệp, nhà máy, sản phẩm hoặc thành tựu | Ảnh sạch để chủ dự án chèn nội dung |
| `03-bia-khung-cam-hook-1080x1920.png` | Một ảnh gốc khác, chèn khung cam nhạt trong mờ, logo nhỏ và hook | Bìa hoàn chỉnh |

Không trả một đống ảnh để chủ dự án tự lựa. Tự chọn, dàn bố cục và kiểm tra trước khi gửi ba thành phẩm để chủ dự án xem lại.

## 2. Đúng người, đúng nguồn, đúng giai đoạn

- Dùng ảnh thật, mặt rõ và nguồn có thể đối chiếu. Không chọn chỉ dựa vào tiêu đề kết quả tìm kiếm.
- Kiểm tra tránh nhầm con trai, anh em, người kế nhiệm, diễn viên khác hoặc một người cùng tên. Nhận diện người trong ảnh nhóm trước khi cắt.
- Ảnh 01 phải nhận rõ nhân vật; không chỉ đưa nhà máy, logo hay tòa nhà khi bài kể về một người.
- Ưu tiên tư liệu quá khứ. Nếu ảnh đúng thời thơ ấu quá nhỏ/mờ, tìm ảnh tư liệu khác rõ hơn; không tự tạo ảnh thời trẻ, ghép cơ thể hoặc biến ảnh mới thành ảnh cũ rồi gọi là tư liệu.
- Kiểm tra năm hoặc giai đoạn chụp nếu nguồn có thông tin. Ảnh thời thành công không nhất thiết là diện mạo hiện tại; không gán ảnh cũ thành ảnh mới.
- Ảnh minh họa không mặc nhiên là ảnh chụp đúng mốc tuổi hay sự kiện trong lời đọc. Ghi rõ giới hạn này trong ghi chú nguồn nội bộ nếu không xác nhận được.
- Nếu tư liệu hiếm đến mức phải đổi loại hình minh họa, nêu rõ cách thay thế; không âm thầm dùng người khác hoặc hình tượng thay cho ảnh thật của nhân vật.

## 3. Không dùng ảnh quá mờ

- Xem ảnh nguồn và bản xuất ở kích thước dùng thực tế. Dung lượng lớn hoặc nhiều pixel không chứng minh ảnh thật sự nét.
- Loại ảnh bị phóng lớn từ nguồn nhỏ, mềm mặt rõ rệt, nén mạnh, vỡ hạt nặng hoặc có watermark đè nhân vật.
- Không dùng nền phóng lớn làm mờ để lấp chỗ trống. Không coi tăng độ nét/phóng to là cách thay cho việc tìm ảnh tốt hơn.
- Khi được báo có ảnh mờ, kiểm tra cả bộ/lô liên quan, không chỉ thay đúng một ví dụ rồi bỏ qua các ảnh khác.

## 4. Chừa vùng chữ, tránh đè mặt

Mẫu chữ nội dung thường nằm ngang ở khoảng **35–55% chiều cao**. Quy đổi cho canvas 1080×1920:

- Ưu tiên toàn bộ mắt, mũi, miệng và cằm của nhân vật chính nằm **trên y=620 px**.
- Giữ khoảng thở trước vùng chữ thử bắt đầu khoảng **y=680 px**.
- Chọn ảnh bán thân rộng hoặc toàn thân; thân áo và bối cảnh nên phủ được phần dưới.
- Tránh ảnh cận mặt lớn nằm giữa khung. Tránh mảng trắng/trống lớn phía dưới khiến ảnh nhìn như chưa hoàn thiện.
- Cắt/ghép để thay đổi bố cục khi ảnh thật cho phép; không tạo thêm phần cơ thể không có trong ảnh.
- Thử **chính nội dung của bài** ở đúng vùng chữ, không chỉ ước lượng bằng một khung rỗng. Kiểm tra ảnh 01 và 02; sau đó bỏ lớp chữ thử trước khi giao.

Các con số là chuẩn bố cục làm việc. Kết quả nhìn thực tế và việc không che mặt vẫn là điều cần kiểm tra trực tiếp.

## 5. Ảnh 02 có doanh nghiệp/sản phẩm: ghép dọc hai nửa

Mặc định cho ảnh 02 dùng cơ sở, nhà máy hoặc sản phẩm:

- Nửa trên: doanh nhân/chủ thương hiệu, rõ mặt.
- Nửa dưới: ảnh thật của công ty, cơ sở lớn, nhà máy, sản phẩm hoặc không gian kinh doanh phù hợp.
- Mốc chia thường ở **y=960 px**. Điều chỉnh cách cắt để mặt vẫn nằm trên vùng chữ.
- Doanh nghiệp và thương hiệu phải dễ nhận ra. Không cắt mất tên thương hiệu quan trọng.
- Chọn cơ sở hoặc quy mô hiện nay khi chủ dự án yêu cầu thể hiện sự phát triển.
- Ảnh doanh nghiệp/sản phẩm phía dưới phải khác ảnh bìa và ảnh 01. Không lặp lại cùng ảnh ở cả nền trên và nửa dưới.

Nếu chủ dự án có yêu cầu riêng như nửa sản phẩm, nửa quán đông khách, thực hiện đúng yêu cầu riêng đó. Với vận động viên/nghệ sĩ, có thể dùng ảnh thành tựu rõ ràng như cúp, huy chương, sân khấu; không bắt buộc bịa thêm một doanh nghiệp.

## 6. Ba ảnh phải khác ảnh gốc

- 01, 02 và 03 dùng ba ảnh gốc khác nhau của nhân vật.
- Kiểm tra cả các thành phần ảnh ghép: công ty, sản phẩm, nhà máy, cảnh nền.
- Cùng một ảnh đổi cách cắt, đổi màu, đổi nền, lật, chụp lại bản in hoặc đặt vào bảng trưng bày vẫn tính là dùng lại ảnh.
- Một ảnh không được lặp ở hai vị trí trong cùng ảnh ghép.
- Khi làm lại một nhân vật đã có bộ cũ, đối chiếu bộ cũ để tránh dùng lại ảnh đã giao.
- Có thể dùng thống nhất logo và khung bìa; đây là thành phần nhận diện được chủ dự án yêu cầu lặp lại.
- Tự động so sánh mã tệp/đặc trưng chỉ giúp phát hiện ứng viên trùng. Phải xem trực tiếp; ảnh khác góc chụp của cùng tòa nhà không tự động là cùng ảnh gốc.

## 7. Bìa: giữ đúng mẫu đã chốt

- Khung chữ nhật bo góc, cam nhạt **trong mờ**, viền sáng. Hiệu ứng mờ nằm ở **khung**, không làm mờ mặt/ảnh nền.
- Dùng `assets/khung-bia-business-now-cam-trong-mo.png`; không tự đổi sang khung xanh, cam đậm hoặc một thiết kế mới.
- Logo `BUSINESS NOW` nhỏ vừa đủ, theo hàng ngang trên mép trên của khung; tách nền, không kèm ô nền xanh cũ.
- Logo rời trong `assets/LOGO Businessnow.png` giữ dạng gốc hai dòng. Logo ngang đã nằm trong khung được duyệt; không tự chồng thêm logo rời lên bìa.
- Font triển khai đang dùng: `Anton-Regular.ttf`; chữ đậm, cao, hẹp. Chữ chính navy **#061329**, dòng nhấn cam đậm **#B84206**.
- Lấy đúng hook từ kịch bản, giữ ý, từ ngữ và dấu câu. Không tự viết lại, lược bớt hoặc thay bằng một tiêu đề mới.
- Ngắt khoảng 2–4 dòng dễ đọc. Kiểm tra đủ dấu tiếng Việt, không cắt dấu, không lỗi mã hóa và không đè lên mặt.
- Mã đã dùng vẽ **đường nét ký tự** thay vì cách xuất chữ có thể làm mất/cắt dấu: `src/render_business_now_hook.ps1`.
- Giữ đủ tên thương hiệu nếu đó là yếu tố cần để người xem nhận ra câu chuyện.

## 8. Lưu và bàn giao gọn

- Mặc định: **`D:\Ảnh GPT`**. Không lưu bộ ảnh mới vào Downloads.
- Mỗi kịch bản một thư mục riêng, ví dụ `D:\Ảnh GPT\321-charlie-chaplin\`.
- Mỗi thư mục chỉ có đúng ba tệp thành phẩm như mục 1.
- Ảnh nguồn, bản thử chữ, ảnh xem trước, ghi chú nguồn, báo cáo và bản sao lưu chỉnh sửa ở thư mục làm việc riêng.
- Chỉ tạo ZIP khi được yêu cầu. Không tự tạo thêm gói nén cho từng đợt ảnh.
- Khi thay ảnh, thay đúng thành phẩm cần sửa, giữ cấu trúc gọn; không để hàng loạt bản nháp/bản cũ trong thư mục giao.
- Không xóa tùy tiện dữ liệu của chủ dự án. Khi dọn ảnh thừa, xác định đúng bộ cần dọn và giữ đủ ba thành phẩm.
- Dùng đường dẫn thật trên ổ D khi gửi liên kết. Trong dự án gốc, `outputs` chỉ là junction trỏ tới `D:\Ảnh GPT`.
- Một yêu cầu riêng lưu logo vào Downloads trong lịch sử không thay đổi mặc định hiện nay là ổ D.

## 9. Kiểm tra trước khi giao

1. Đủ ba ảnh, đúng người, đúng số bài và đúng giai đoạn minh họa.
2. Mỗi PNG đúng 1080×1920; không lấy ảnh đã quá mờ để phóng lớn.
3. Mặt rõ, nằm trên vùng chữ; đã thử nội dung thật lên ảnh 01/02.
4. Ảnh 02 ghép đúng người và đúng cơ sở/sản phẩm khi dùng dạng ghép.
5. Ba ảnh và các thành phần ghép không dùng lại cùng một ảnh gốc; đối chiếu bộ cũ nếu có.
6. Bìa có đúng khung cam trong mờ, logo nhỏ ngang, hook nguyên văn và đủ dấu.
7. Không cắt mất yếu tố nhận diện thương hiệu quan trọng.
8. Hai ảnh nội dung giao bản sạch. Thư mục trên D chỉ có ba PNG thành phẩm.
