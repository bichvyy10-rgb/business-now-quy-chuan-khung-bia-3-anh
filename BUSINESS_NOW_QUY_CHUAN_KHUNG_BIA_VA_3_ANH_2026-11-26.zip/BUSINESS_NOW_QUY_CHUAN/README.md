# BUSINESS NOW — Khung bìa và quy chuẩn tìm 3 ảnh

Bộ dữ liệu bàn giao theo các yêu cầu, chỉnh sửa và ghi chú của chủ dự án đến **26/11/2026**. Mục đích là tái tạo đúng khung bìa đã chốt và giữ thống nhất cách tìm, chọn, cắt, ghép, kiểm tra, lưu ảnh cho các kịch bản mới.

## Nội dung gói

- `QUY_UOC_CHUAN.md`: quy trình áp dụng cho mỗi kịch bản.
- `GHI_CHU_CHINH_SUA.md`: những lỗi chủ dự án đã chỉ ra, cách xử lý và các trường hợp riêng.
- `BUSINESS_NOW_QUY_UOC_ANH.txt`: bản quy ước gốc đang dùng trong dự án, giữ nguyên nội dung để đối chiếu.
- `PROMPT_KHOI_DONG.txt`: yêu cầu khởi động ngắn để chuyển giao quy trình.
- `THONG_SO_KHUNG.json`: thông số bố cục, màu chữ, vị trí chữ và tên tệp.
- `assets/`: **chỉ** có khung trong suốt, logo tách nền và font cần để tái tạo mẫu.
- `src/`: mã vẽ hook tiếng Việt đã dùng và lệnh tạo bìa từ ảnh đã dàn bố cục.
- `licenses/Anton-OFL.txt`: giấy phép đi kèm font Anton.
- `MANIFEST_SHA256.json`: danh sách tệp và mã kiểm tra tính toàn vẹn.

Gói này **không chứa** ảnh nhân vật, ảnh doanh nghiệp, ảnh nguồn đã tìm, các bộ ảnh thành phẩm, kịch bản nội dung, thông tin đăng nhập hoặc dữ liệu cá nhân khác trên máy.

## Bắt đầu

1. Đọc `QUY_UOC_CHUAN.md`, sau đó đọc `GHI_CHU_CHINH_SUA.md`.
2. Dùng `PROMPT_KHOI_DONG.txt` làm yêu cầu chuyển giao, rồi cung cấp số bài/kịch bản cần làm.
3. Tìm ảnh thật, kiểm tra đúng người và chọn ba ảnh gốc khác nhau.
4. Cắt/ghép ảnh sạch 01 và 02, thử chữ ở đúng vị trí, rồi xuất bìa 03 bằng khung và hook.
5. Lưu đúng ba PNG vào `D:\Ảnh GPT\<số-bài>-<tên>\`.

## Tạo bìa trên Windows

Ảnh nền phải được bố cục sẵn ở **1080×1920**. Lệnh này ghép mẫu bìa đã chốt; nó không tự tìm ảnh, nhận diện mặt hay quyết định cách cắt.

Tạo tệp UTF-8 `hook.txt`, ưu tiên chia sẵn hook thành 2–4 dòng. Ví dụ:

```text
CHỮ TIẾNG VIỆT
PHẢI ĐẦY ĐỦ
KHÔNG MẤT DẤU.
```

Chạy trong PowerShell tại thư mục đã giải nén:

```powershell
.\src\Tao-Bia.ps1 -AnhNen 'D:\Ảnh GPT\anh-nen-1080x1920.png' -HookFile '.\hook.txt' -LuuThanh 'D:\Ảnh GPT\03-bia-khung-cam-hook-1080x1920.png'
```

Nếu hook chỉ có một dòng, lệnh sẽ chia dòng sơ bộ; cần kiểm tra lại cách ngắt câu trên ảnh. Tham số `-DichKhung 80` dịch cả khung và chữ xuống 80 px khi cần giữ khoảng cách với khuôn mặt. Không dùng việc dịch khung để chữa một ảnh nền không phù hợp.

Mã vẽ chữ dùng đường nét ký tự để giữ đầy đủ dấu tiếng Việt. Mẫu ảnh, màu và font được lấy từ bộ đang dùng trong dự án; không phải khung thiết kế lại.

## Thứ tự áp dụng

Yêu cầu mới, rõ ràng của chủ dự án được ưu tiên. Các quy tắc mặc định không biến thành một tác vụ chạy định kỳ và không tự mở rộng sang viết kịch bản hoặc dựng video.

Tài liệu phân biệt yêu cầu của chủ dự án với các lựa chọn triển khai trước đây; những ví dụ theo số bài không tự động trở thành ngoại lệ cho bài mới.
