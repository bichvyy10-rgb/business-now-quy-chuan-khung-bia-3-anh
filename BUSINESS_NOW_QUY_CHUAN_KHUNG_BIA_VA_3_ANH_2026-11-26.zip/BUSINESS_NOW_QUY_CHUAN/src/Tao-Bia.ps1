﻿param(
    [Parameter(Mandatory=$true)][string] $AnhNen,
    [Parameter(Mandatory=$true)][string] $HookFile,
    [string] $LuuThanh = 'D:\Ảnh GPT\03-bia-khung-cam-hook-1080x1920.png',
    [ValidateRange(0,350)][int] $DichKhung = 0
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$packageRoot = Split-Path $PSScriptRoot -Parent
. (Join-Path $PSScriptRoot 'render_business_now_hook.ps1')
$framePath = Join-Path $packageRoot 'assets\khung-bia-business-now-cam-trong-mo.png'
$fontPath = Join-Path $packageRoot 'assets\Anton-Regular.ttf'
$sourcePath = (Resolve-Path -LiteralPath $AnhNen).Path
$hookPath = (Resolve-Path -LiteralPath $HookFile).Path
$outputPath = [System.IO.Path]::GetFullPath($LuuThanh)
if ($sourcePath -eq $outputPath) { throw 'Source and output paths must differ.' }
if ([System.IO.Path]::GetExtension($outputPath) -ne '.png') { throw 'Output must use the .png extension.' }
$lines = @(Get-Content -LiteralPath $hookPath -Encoding UTF8 | ForEach-Object { $_.Trim() } | Where-Object { $_ })
if ($lines.Count -eq 0) { throw 'Hook file is empty.' }
$hook = ($lines -join ' ').ToUpperInvariant()
if ($lines.Count -eq 1 -or $lines.Count -gt 4) {
    $words = @($hook -split '\s+')
    $lineCount = if ($words.Count -lt 7) { 2 } else { 3 }
    $lineCount = [Math]::Min($lineCount,$words.Count)
    $result = New-Object System.Collections.Generic.List[string]
    $current = ''; $remaining = $hook.Length
    foreach ($word in $words) {
        $needed = $lineCount - $result.Count
        $target = if ($needed -gt 0) { $remaining / $needed } else { $remaining }
        $trial = ($current + ' ' + $word).Trim()
        if ($current -and $needed -gt 1 -and $trial.Length -gt ($target + $word.Length / 2)) {
            $result.Add($current); $remaining -= $current.Length + 1; $current = $word
        } else { $current = $trial }
    }
    if ($current) { $result.Add($current) }
    $lines = @($result.ToArray())
} else { $lines = @($lines | ForEach-Object { $_.ToUpperInvariant() }) }
if ((($lines -join ' ') -replace '\s+',' ') -ne ($hook -replace '\s+',' ')) { throw 'Hook words changed while wrapping.' }
$source = $null; $overlay = $null; $bitmap = $null; $graphics = $null
try {
    $source = [System.Drawing.Image]::FromFile($sourcePath)
    if ($source.Width -ne 1080 -or $source.Height -ne 1920) { throw 'Prepare the background at exactly 1080x1920 before adding the cover.' }
    $overlay = [System.Drawing.Image]::FromFile($framePath)
    $bitmap = New-Object System.Drawing.Bitmap 1080,1920
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $graphics.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
    $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.DrawImageUnscaled($source,0,0)
    $graphics.DrawImage($overlay,0,$DichKhung,1080,1920)
    $graphics.TranslateTransform(0,[single]$DichKhung)
    Add-BusinessNowHook -Graphics $graphics -FontPath $fontPath -Lines $lines
    $graphics.ResetTransform()
    $directory = Split-Path $outputPath -Parent
    if (-not (Test-Path -LiteralPath $directory)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
    $bitmap.Save($outputPath,[System.Drawing.Imaging.ImageFormat]::Png)
    Write-Output $outputPath
} finally {
    if ($graphics) { $graphics.Dispose() }
    if ($bitmap) { $bitmap.Dispose() }
    if ($overlay) { $overlay.Dispose() }
    if ($source) { $source.Dispose() }
}
