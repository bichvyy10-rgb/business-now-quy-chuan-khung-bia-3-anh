﻿function Add-BusinessNowHook {
    param(
        [System.Drawing.Graphics]$Graphics,
        [string]$FontPath,
        [string[]]$Lines
    )
    # Draw actual outlines, so Vietnamese marks are not clipped to GDI text cells.
    $private=New-Object System.Drawing.Text.PrivateFontCollection
    $private.AddFontFile($FontPath)
    $family=$private.Families[0]
    $paths=@();$totalHeight=0;$widest=0
    foreach($line in $Lines) {
        $path=New-Object System.Drawing.Drawing2D.GraphicsPath
        $path.FillMode=[System.Drawing.Drawing2D.FillMode]::Winding
        $path.AddString($line,$family,0,108,(New-Object System.Drawing.PointF 0,0),[System.Drawing.StringFormat]::GenericTypographic)
        $bounds=$path.GetBounds()
        $totalHeight+=$bounds.Height
        $widest=[Math]::Max($widest,$bounds.Width)
        $paths+=$path
    }
    $gap=14
    $scale=[Math]::Min(936/$widest,385/$totalHeight)
    $groupHeight=$totalHeight*$scale+($Lines.Length-1)*$gap
    $positionY=1030+(420-$groupHeight)/2
    $navy=New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml('#061329'))
    $burnt=New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml('#B84206'))
    $edge=New-Object System.Drawing.Pen ([System.Drawing.ColorTranslator]::FromHtml('#FFF6EE')),1.5
    $edge.LineJoin=[System.Drawing.Drawing2D.LineJoin]::Round
    for($index=0;$index -lt $paths.Length;$index++) {
        $path=$paths[$index]
        $bounds=$path.GetBounds()
        $matrix=New-Object System.Drawing.Drawing2D.Matrix
        $matrix.Translate([single](-$bounds.X),[single](-$bounds.Y))
        $path.Transform($matrix);$matrix.Dispose()
        $matrix=New-Object System.Drawing.Drawing2D.Matrix
        $matrix.Scale([single]$scale,[single]$scale)
        $path.Transform($matrix);$matrix.Dispose()
        $bounds=$path.GetBounds()
        $matrix=New-Object System.Drawing.Drawing2D.Matrix
        $matrix.Translate([single]((1080-$bounds.Width)/2),[single]$positionY)
        $path.Transform($matrix);$matrix.Dispose()
        $fill=if($index -eq $paths.Length-1){$burnt}else{$navy}
        $Graphics.DrawPath($edge,$path)
        $Graphics.FillPath($fill,$path)
        $positionY+=$bounds.Height+$gap
        $path.Dispose()
    }
    $navy.Dispose();$burnt.Dispose();$edge.Dispose();$private.Dispose()
}
